"use client"

import React, { useEffect, useRef, useState } from "react"
import MainLayout from "../../LayOut/MainLayout"
// Use absolute imports instead of relative paths
import NumberOfAnimals from "/components/pages/NumberOfAnimals/NumberOfAnimals"
import GeneralHealth from "/components/pages/GeneralHealth/GeneralHealth"
import FeedingAlarm from "/components/pages/FeednigAlarm/FeedingAlarm"
import FeedingStatus from "/components/pages/FeedingStatus/FeedingStatus"
import Metrics from "/components/pages/metrics/Metrics"
import QuickMonitoring from "/components/pages/quickMonitoring/QuickMonitoring"

// Error boundary for component error handling
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props)
    this.state = { hasError: false }
  }

  static getDerivedStateFromError(error) {
    return { hasError: true }
  }

  componentDidCatch(error, errorInfo) {
    console.error("Component error:", error, errorInfo)
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback || <div>Something went wrong.</div>
    }
    return this.props.children
  }
}

const DashboardMain = () => {
  const containerRef = useRef(null)
  const [containerHeight, setContainerHeight] = useState(0)

  // Calculate available height and adjust layout
  useEffect(() => {
    document.title = "Dashboard | DalensAI"

    const updateHeight = () => {
      if (containerRef.current) {
        // Get viewport height
        const viewportHeight = window.innerHeight
        // Account for padding and other elements
        const offsetTop = containerRef.current.getBoundingClientRect().top
        // Calculate available height
        const availableHeight = viewportHeight - offsetTop - 24 // 24px for bottom padding
        setContainerHeight(availableHeight)
      }
    }

    // Initial calculation
    updateHeight()

    // Update on resize
    window.addEventListener("resize", updateHeight)
    return () => window.removeEventListener("resize", updateHeight)
  }, [])

  return (
    <MainLayout activePage="dashboard">
      <div className="w-full bg-gray-50 min-h-screen">
        <div
          className="p-4 lg:p-6"
          ref={containerRef}
          style={{ height: containerHeight ? `${containerHeight}px` : "auto" }}
        >
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 h-full max-w-[1920px] mx-auto">
            {/* Main content area - 2/3 width */}
            <div className="xl:col-span-2 flex flex-col gap-6 h-full">
              {/* Video stream - 2/3 of available height */}
              <div className="flex-grow" style={{ height: "calc(66.67% - 12px)" }}>
                <ErrorBoundary>
                  <div className="bg-white/95 backdrop-blur-sm rounded-xl shadow-md overflow-hidden h-full border border-gray-100 flex flex-col">
                    <div className="bg-gray-800 text-white text-sm px-4 py-2 font-medium">Live Video Stream</div>
                    <div className="flex-grow overflow-hidden">
                      <QuickMonitoring />
                    </div>
                  </div>
                </ErrorBoundary>
              </div>

              {/* Metrics section - 1/3 of available height */}
              <div className="flex-grow" style={{ height: "calc(33.33% - 12px)" }}>
                <ErrorBoundary>
                  <div className="bg-white/95 backdrop-blur-sm rounded-xl shadow-md overflow-hidden h-full border border-gray-100 flex flex-col">
                    <div className="bg-gray-800 text-white text-sm px-4 py-2 font-medium">Performance Metrics</div>
                    <div className="flex-grow overflow-auto">
                      <Metrics />
                    </div>
                  </div>
                </ErrorBoundary>
              </div>
            </div>

            {/* Sidebar - 1/3 width */}
            <div className="flex flex-col gap-6 h-full">
              {/* Calculate height dynamically for each sidebar component */}
              <div className="flex-grow" style={{ height: "calc(25% - 18px)" }}>
                <ErrorBoundary>
                  <div className="bg-white/95 backdrop-blur-sm rounded-xl shadow-md h-full border border-gray-100 flex flex-col">
                    <div className="text-gray-800 text-base font-medium px-5 pt-5 pb-2 border-b">Animal Statistics</div>
                    <div className="flex-grow p-5 pt-3 overflow-auto">
                      <NumberOfAnimals />
                    </div>
                  </div>
                </ErrorBoundary>
              </div>

              <div className="flex-grow" style={{ height: "calc(25% - 18px)" }}>
                <ErrorBoundary>
                  <div className="bg-white/95 backdrop-blur-sm rounded-xl shadow-md h-full border border-gray-100 flex flex-col">
                    <div className="text-gray-800 text-base font-medium px-5 pt-5 pb-2 border-b">Health Monitor</div>
                    <div className="flex-grow p-5 pt-3 overflow-auto">
                      <GeneralHealth />
                    </div>
                  </div>
                </ErrorBoundary>
              </div>

              <div className="flex-grow" style={{ height: "calc(25% - 18px)" }}>
                <ErrorBoundary>
                  <div className="bg-white/95 backdrop-blur-sm rounded-xl shadow-md h-full border border-gray-100 flex flex-col">
                    <div className="text-gray-800 text-base font-medium px-5 pt-5 pb-2 border-b">Feeding Alerts</div>
                    <div className="flex-grow p-5 pt-3 overflow-auto">
                      <FeedingAlarm />
                    </div>
                  </div>
                </ErrorBoundary>
              </div>

              <div className="flex-grow" style={{ height: "calc(25% - 18px)" }}>
                <ErrorBoundary>
                  <div className="bg-white/95 backdrop-blur-sm rounded-xl shadow-md h-full border border-gray-100 flex flex-col">
                    <div className="text-gray-800 text-base font-medium px-5 pt-5 pb-2 border-b">Feed Level Status</div>
                    <div className="flex-grow p-5 pt-3 overflow-auto">
                      <FeedingStatus />
                    </div>
                  </div>
                </ErrorBoundary>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  )
}

export default DashboardMain
