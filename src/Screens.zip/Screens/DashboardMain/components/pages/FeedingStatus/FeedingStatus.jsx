"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import "./FeedingStatus.css"

const FeedingStatus = () => {
  const [level, setLevel] = useState(100)
  const [status, setStatus] = useState('Normal')
  const [isAnimating, setIsAnimating] = useState(true)

  const decreaseLevel = () => {
    setLevel(prevLevel => {
      const newLevel = Math.max(0, prevLevel - 0.1)
      
      // Update status based on level
      if (newLevel < 30) {
        setStatus('Low')
      } else if (newLevel < 60) {
        setStatus('Medium')
      } else {
        setStatus('Normal')
      }
      
      return newLevel
    })
  }

  useEffect(() => {
    // Decrease level every 100ms for smooth animation
    const interval = setInterval(decreaseLevel, 100)
    return () => clearInterval(interval)
  }, [])

  const getStatusColor = () => {
    switch (status) {
      case 'Low':
        return '#E05100'
      case 'Medium':
        return '#FFC107'
      default:
        return '#70E000'
    }
  }

  return (
    <div className="w-full bg-white rounded-lg border shadow-sm overflow-hidden">
      <div className="p-4 border-b">
        <h2 className="text-lg font-medium">Feed Level</h2>
      </div>

      <div className="p-4 flex flex-col items-center">
        {/* Circular Tank */}
        <div className="tank-container">
          {/* Level Marks */}
          <div className="level-marks">
            <div className="level-mark p100"></div>
            <div className="level-mark p75"></div>
            <div className="level-mark p50"></div>
            <div className="level-mark p25"></div>
            <div className="level-mark p0"></div>
          </div>
          
          {/* Liquid */}
          <div 
            className="liquid"
            style={{ 
              height: `${level}%`,
              backgroundColor: getStatusColor(),
            }}
          >
            <div className="wave"></div>
            <div className="shine"></div>
          </div>

          {/* Percentage Display */}
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-3xl font-bold text-gray-800 z-10 drop-shadow">
              {Math.round(level)}%
            </span>
          </div>
        </div>

        {/* Status */}
        <div className="mt-4 text-center">
          <div className={`text-sm font-medium ${status === 'Low' ? 'text-red-500' : status === 'Medium' ? 'text-yellow-500' : 'text-green-500'}`}>
            {status === 'Low' ? 'Low Feed Level' : status === 'Medium' ? 'Medium Feed Level' : 'Normal Feed Level'}
          </div>
        </div>
      </div>
    </div>
  )
}

export default FeedingStatus
