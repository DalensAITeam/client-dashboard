"use client"

import React, { useState, useEffect } from "react"
import "./FeedingAlarm.css"

const FeedingAlarm = ({ feedingStatus }) => {
  const [alarmTime, setAlarmTime] = useState("08:00")
  const [isAlarmActive, setIsAlarmActive] = useState(true)
  const [nextAlarm, setNextAlarm] = useState("")

  // Calculate next alarm time
  const calculateNextAlarm = (timeString) => {
    const now = new Date()
    const [hours, minutes] = timeString.split(":").map(Number)
    const alarmDate = new Date()
    alarmDate.setHours(hours, minutes, 0, 0)

    if (alarmDate < now) {
      alarmDate.setDate(alarmDate.getDate() + 1)
    }

    const timeUntil = alarmDate - now
    const hoursUntil = Math.floor(timeUntil / (1000 * 60 * 60))
    const minutesUntil = Math.floor((timeUntil % (1000 * 60 * 60)) / (1000 * 60))

    setNextAlarm(`${hoursUntil}h ${minutesUntil}m`)
  }

  useEffect(() => {
    calculateNextAlarm(alarmTime)
    const interval = setInterval(() => calculateNextAlarm(alarmTime), 60000)
    return () => clearInterval(interval)
  }, [alarmTime])

  // Get alarm status based on feeding status
  const getAlarmStatus = (feeding) => {
    if (feeding < 30) return { level: 'Critical', color: 'text-red-500', bgColor: 'bg-red-100' }
    if (feeding < 50) return { level: 'Warning', color: 'text-yellow-500', bgColor: 'bg-yellow-100' }
    return { level: 'Normal', color: 'text-green-500', bgColor: 'bg-green-100' }
  }

  const alarmStatus = getAlarmStatus(feedingStatus)

  return (
    <div className="flex flex-col h-full w-full">
      <h2 className="text-lg font-semibold text-gray-800 mb-4">
        Feeding Schedule
      </h2>

      <div className="flex-1 flex flex-col">
        {/* Time setting */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <input
              type="time"
              value={alarmTime}
              onChange={(e) => {
                setAlarmTime(e.target.value)
                calculateNextAlarm(e.target.value)
              }}
              className="p-2 rounded border text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button
              onClick={() => setIsAlarmActive(!isAlarmActive)}
              className={`ml-2 px-3 py-1 rounded-full text-sm font-medium ${
                isAlarmActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
              }`}
            >
              {isAlarmActive ? 'Active' : 'Inactive'}
            </button>
          </div>
        </div>

        {/* Status display */}
        <div className={`p-4 rounded-lg ${alarmStatus.bgColor} mb-4`}>
          <div className="flex items-center justify-between">
            <div>
              <div className={`text-sm font-medium ${alarmStatus.color}`}>
                Next feeding in:
              </div>
              <div className="text-2xl font-bold text-gray-800">
                {nextAlarm}
              </div>
            </div>
            <div className={`text-lg font-medium ${alarmStatus.color}`}>
              {alarmStatus.level}
            </div>
          </div>
        </div>
      </div>

      {/* Last updated timestamp */}
      <div className="mt-auto pt-4 text-xs text-gray-500">
        Last Updated: {new Date().toLocaleTimeString()}
      </div>
    </div>
  )
}

export default FeedingAlarm
