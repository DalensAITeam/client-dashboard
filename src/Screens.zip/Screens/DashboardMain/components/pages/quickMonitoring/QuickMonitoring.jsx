"use client"

import "./monitoring.css"
import { useState, useEffect } from "react"
import { useSelector } from "react-redux"
import VideoStream from "../../../../../components/VideoStream/VideoStream"
import { Link } from "react-router-dom"

// Available videos in the backend folder with full paths
const AVAILABLE_VIDEOS = [
  '/home/gargarmel/DalenseAI/FlaskAI_backend/videos/chick-1.mp4',
  '/home/gargarmel/DalenseAI/FlaskAI_backend/videos/chick-2.mp4',
  '/home/gargarmel/DalenseAI/FlaskAI_backend/videos/chick.mp4',
  '/home/gargarmel/DalenseAI/FlaskAI_backend/videos/chicks.mp4',
  '/home/gargarmel/DalenseAI/FlaskAI_backend/videos/cow-1.mp4',
  '/home/gargarmel/DalenseAI/FlaskAI_backend/videos/cow-2.mp4',
  '/home/gargarmel/DalenseAI/FlaskAI_backend/videos/cow.mp4',
  '/home/gargarmel/DalenseAI/FlaskAI_backend/videos/goat.mp4',
  '/home/gargarmel/DalenseAI/FlaskAI_backend/videos/livestock.mp4',
  '/home/gargarmel/DalenseAI/FlaskAI_backend/videos/pigs-1.mp4',
  '/home/gargarmel/DalenseAI/FlaskAI_backend/videos/pigs-2.mp4',
  '/home/gargarmel/DalenseAI/FlaskAI_backend/videos/pigs.mp4'
];

// Get a random video from the available videos
const getRandomVideo = () => {
  const randomIndex = Math.floor(Math.random() * AVAILABLE_VIDEOS.length);
  return AVAILABLE_VIDEOS[randomIndex];
};

// Format video title from path
const getVideoTitle = (videoPath) => {
  const filename = videoPath.split('/').pop().split('.')[0];
  return filename
    .split('-')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};

const QuickMonitoring = () => {
  const [videoSource, setVideoSource] = useState(getRandomVideo());
  const [videoTitle, setVideoTitle] = useState('');
  
  // Change video every 30 seconds
  useEffect(() => {
    setVideoTitle(getVideoTitle(videoSource));
    
    const interval = setInterval(() => {
      const newVideo = getRandomVideo();
      setVideoSource(newVideo);
      setVideoTitle(getVideoTitle(newVideo));
    }, 30000);
    
    return () => clearInterval(interval);
  }, [videoSource]);

  return (
    <div className="flex flex-col h-full">
      <div className="flex justify-between items-center p-4 border-b">
        <h1 className="text-lg font-medium">Quick Monitoring: {videoTitle}</h1>
        <Link to="/farm-monitor">
          <button className="text-sm text-green-400 cursor-pointer hover:text-green-500">
            See more
          </button>
        </Link>
      </div>

      <div className="flex-1 p-4">
        <div className="relative w-full h-full bg-gray-900 rounded-lg overflow-hidden shadow-lg">
          <div className="w-full h-full" style={{ aspectRatio: '16/9', maxHeight: 'calc(100vh - 220px)' }}>
            <VideoStream
              videoUrl={videoSource}
              title={videoTitle}
              className="w-full h-full"
              aspectRatio="16/9"
              onStreamError={(err) => {
                console.error("Stream error:", err);
                // Try another video on error
                const newVideo = getRandomVideo();
                setVideoSource(newVideo);
                setVideoTitle(getVideoTitle(newVideo));
              }}
            />
            
            {/* Status overlay */}
            <div className="absolute bottom-4 left-4 bg-black/50 px-3 py-1 rounded-lg text-white text-sm">
              <span className="inline-block w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></span>
              <span>Live Feed</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default QuickMonitoring
