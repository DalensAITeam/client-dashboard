"use client";

import React, { useState, useEffect } from "react";
import "./NumberOfAnimals.css";

const NumberOfAnimals = () => {
  const [stats, setStats] = useState({
    total: Math.floor(Math.random() * (120 - 80 + 1)) + 80,  // Random between 80-120
    healthy: 0,
    danger: 0,
    feeding: 0
  })

  const generateRandomStats = () => {
    const total = Math.floor(Math.random() * (120 - 80 + 1)) + 80
    const healthy = Math.floor(total * (Math.random() * (0.8 - 0.6) + 0.6)) // 60-80% healthy
    const danger = Math.floor(total * (Math.random() * (0.2 - 0.1) + 0.1))   // 10-20% in danger
    const feeding = Math.floor(total * (Math.random() * (0.3 - 0.1) + 0.1))   // 10-30% feeding

    setStats({
      total,
      healthy,
      danger,
      feeding
    })
  }

  const [streamStats, setStreamStats] = useState({
    animal_count: 0,
    healthy_count: 0,
    attack_count: 0,
    feeding_count: 0
  })

  const fetchStats = async () => {
    try {
      const response = await fetch('http://localhost:7017/api/stats')
      const data = await response.json()
      setStreamStats({
        animal_count: data.animal_count || 0,
        healthy_count: data.healthy_count || 0,
        attack_count: data.attack_count || 0,
        feeding_count: data.feeding_count || 0
      })
    } catch (error) {
      console.error('Error fetching stats:', error)
    }
  }

  useEffect(() => {
    generateRandomStats()
    const interval = setInterval(generateRandomStats, 5000) // Update every 5 seconds
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="w-full bg-white rounded-lg border shadow-sm overflow-hidden">
      <div className="p-4 border-b">
        <h2 className="text-lg font-medium text-center">Animal Statistics</h2>
      </div>

      <div className="p-6">
        {/* Total Animals - Centered and Larger */}
        <div className="text-center mb-8">
          <div className="text-4xl font-bold mb-2">{stats.total}</div>
          <div className="text-sm text-gray-500">Total Animals</div>
        </div>

        {/* Other Stats - 3 Column Layout */}
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-500 mb-1">{stats.healthy}</div>
            <div className="text-sm text-gray-500">Healthy</div>
          </div>
          
          <div className="text-center border-x border-gray-200">
            <div className="text-2xl font-bold text-red-500 mb-1">{stats.danger}</div>
            <div className="text-sm text-gray-500">In Danger</div>
          </div>
          
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-500 mb-1">{stats.feeding}</div>
            <div className="text-sm text-gray-500">Feeding</div>
          </div>
        </div>
      </div>
      <p className="text-sm text-gray-500 mt-2">
        Last Updated: {new Date().toLocaleTimeString()}
      </p>
    </div>
  );
};

export default NumberOfAnimals;
