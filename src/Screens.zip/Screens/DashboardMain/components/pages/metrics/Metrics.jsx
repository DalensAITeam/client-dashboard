"use client"

import { useEffect, useState } from "react"
import { Line } from "react-chartjs-2"
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js"

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
)

// Chart data for different time periods
const chartData = {
  week: [
    [
      { date: "2023-09-25", result: "2" },
      { date: "2023-09-26", result: "4" },
      { date: "2023-09-27", result: "6" },
      { date: "2023-09-28", result: "8" },
      { date: "2023-09-29", result: "10" },
      { date: "2023-09-30", result: "12" },
      { date: "2023-10-01", result: "14" }
    ]
    // Add other week data arrays here
  ],
  month: [
    // Add month data arrays here
  ],
  year: [
    // Add year data arrays here
  ]
}

const Metrics = () => {
  const [selectedPeriod, setSelectedPeriod] = useState("week")
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)
  const [chartData, setChartData] = useState(null)

  const fetchMetrics = async () => {
    try {
      setIsLoading(true)
      const response = await fetch('http://localhost:7017/api/stats')
      const data = await response.json()
      
      setChartData({
        labels: data.timestamps || ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
        datasets: [
          {
            label: "Movement Rate",
            data: data.movement_history || [65, 59, 80, 81, 56, 55, 40],
            borderColor: "#70E000",
            backgroundColor: "#70E000",
            tension: 0.1
          },
          {
            label: "Feeding Rate",
            data: data.feeding_history || [45, 49, 60, 71, 46, 45, 30],
            borderColor: "#E05100",
            backgroundColor: "#E05100",
            tension: 0.1
          },
          {
            label: "Animal Health",
            data: data.health_history || [75, 79, 85, 81, 76, 85, 80],
            borderColor: "#01A9F2",
            backgroundColor: "#01A9F2",
            tension: 0.1
          }
        ]
      })
      setError(null)
    } catch (err) {
      console.error("Error loading metrics:", err)
      setError("Failed to load metrics")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchMetrics()
    const interval = setInterval(fetchMetrics, 30000)
    return () => clearInterval(interval)
  }, [selectedPeriod])

  if (isLoading) {
    return (
      <div className="w-full h-full bg-white rounded-lg border shadow-sm overflow-hidden p-4">
        <div className="flex justify-center items-center h-full">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full h-full bg-white rounded-lg border shadow-sm overflow-hidden p-4">
        <div className="flex justify-center items-center h-full text-red-500">
        {error}
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full bg-white rounded-lg border shadow-sm overflow-hidden">
      <div className="flex flex-col h-full">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-lg font-medium">Animal Metrics</h2>
          <div className="flex rounded-md border">
          <button
            className={`px-3 py-1 text-sm ${
              selectedPeriod === "week" ? "bg-lime-500 text-white" : "bg-white text-gray-700 hover:bg-gray-100"
            }`}
            onClick={() => setSelectedPeriod("week")}
          >
            Week
          </button>
          <button
            className={`px-3 py-1 text-sm ${
              selectedPeriod === "month" ? "bg-lime-500 text-white" : "bg-white text-gray-700 hover:bg-gray-100"
            }`}
            onClick={() => setSelectedPeriod("month")}
          >
            Month
          </button>
          <button
            className={`px-3 py-1 text-sm ${
              selectedPeriod === "year" ? "bg-lime-500 text-white" : "bg-white text-gray-700 hover:bg-gray-100"
            }`}
            onClick={() => setSelectedPeriod("year")}
          >
            Year
          </button>
        </div>
      </div>

      <div className="flex-1 p-4">
        {isLoading ? (
          <div className="flex justify-center items-center h-full">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
          </div>
        ) : error ? (
          <div className="flex justify-center items-center h-full text-red-500">{error}</div>
        ) : chartData ? (
          <div className="relative w-full" style={{ height: '400px' }}>
            <Line
              data={chartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    position: 'bottom',
                    labels: {
                      usePointStyle: true,
                      padding: 20
                    }
                  }
                },
                scales: {
                  y: {
                    beginAtZero: true,
                    grid: {
                      display: true,
                      color: 'rgba(0,0,0,0.1)'
                    }
                  },
                  x: {
                    grid: {
                      display: false
                    }
                  }
                }
              }}
            />
          </div>
        ) : null}

        </div>
      </div>
    </div>
  )
}

export default Metrics

