import React, { useState } from "react";
import { useSelector } from "react-redux";
import VideoPlayer from "../../../components/VideoPlayer/VideoPlayer";

function ListView({ setViewState }) {
  const [selectedCamera, setSelectedCamera] = useState(0);
  const [error, setError] = useState(null);
  const cameras = useSelector((state) => state.actions.cameras) || [
    { id: 0, name: "Camera 1", videoUrl: "http://localhost:7017/video_feed/0" },
    { id: 1, name: "Camera 2", videoUrl: "http://localhost:7017/video_feed/1" },
    { id: 2, name: "Camera 3", videoUrl: "http://localhost:7017/video_feed/2" },
    { id: 3, name: "Camera 4", videoUrl: "http://localhost:7017/video_feed/3" },
  ];

  return (
    <>
      <div className="flex h-full w-full overflow-hidden pt-16">
        {/* Left sidebar with camera thumbnails */}
        <div className="w-[240px] bg-gray-50 border-r border-gray-200 overflow-y-auto hide-scrollbar">
          <div className="sticky top-0 bg-gray-50 p-3 border-b border-gray-200 z-10">
            <h3 className="text-sm font-medium text-gray-700">Live Feeds</h3>
          </div>
          <div className="p-2 space-y-2">
            {cameras.map((camera, index) => (
              <div
                key={camera.id}
                onClick={() => setSelectedCamera(index)}
                className={`group relative cursor-pointer rounded-md overflow-hidden ${selectedCamera === index ? 'ring-2 ring-green-500' : 'hover:ring-2 hover:ring-gray-300'}`}
              >
                <div className="aspect-video bg-gray-900 rounded-lg overflow-hidden">
                  <VideoPlayer
                    src={camera.videoUrl}
                    title={`Camera ${index + 1}`}
                    className="w-full h-full"
                    aspectRatio="16/9"
                  />
                </div>
                <div className="absolute inset-0 flex items-center justify-center bg-black/0 group-hover:bg-black/20 transition-colors">
                  <span className="text-xs font-medium text-white bg-black/50 px-2 py-1 rounded">
                    {camera.name}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Main content area */}
        <div className="flex-1 relative">
          <div className="absolute inset-0 p-4 flex flex-col">
            {/* Main Video Stream */}
            <div className="relative flex-1 bg-gray-900 rounded-lg overflow-hidden shadow-lg">
              <div className="w-full h-full" style={{ aspectRatio: '16/9', maxHeight: 'calc(100vh - 220px)' }}>
                <VideoPlayer
                  src={cameras[selectedCamera].videoUrl}
                  title={`Camera ${selectedCamera + 1}`}
                  className="w-full h-full"
                  aspectRatio="16/9"
                />
              </div>
              {/* Camera selector overlay */}
              <div className="absolute top-4 right-4 z-10">
                <select
                  value={selectedCamera}
                  onChange={(e) => setSelectedCamera(Number(e.target.value))}
                  className="bg-black/50 text-white px-3 py-2 rounded-md border border-white/20 focus:outline-none focus:ring-2 focus:ring-green-500 backdrop-blur-sm"
                >
                  {cameras.map((camera, index) => (
                    <option key={camera.id} value={index}>
                      {camera.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Camera Info */}
            <div className="mt-4 grid grid-cols-3 gap-4 pb-4">
              <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg shadow-lg text-white">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium">Camera Status</h3>
                  <div className="px-2 py-1 rounded text-sm bg-green-500/20 text-green-100">
                    Active
                  </div>
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg shadow-lg text-white">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium">Resolution</h3>
                  <span>1080p</span>
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg shadow-lg text-white">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium">Frame Rate</h3>
                  <span>30 FPS</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default ListView;
