import React, { useState } from "react";
import VideoStream from "../../../components/VideoStream/VideoStream";
import VideoStreamPlaceholder from "../../../components/VideoStream/VideoStreamPlaceholder";
import { useSelector } from "react-redux";

function ViewType({ setViewState }) {
  const cameras = useSelector((state) => state.actions.cameras) || [
    { id: 0, name: "Camera 1", videoUrl: "/videos/sample1.mp4" },
    { id: 1, name: "Camera 2", videoUrl: "/videos/sample2.mp4" },
    { id: 2, name: "Camera 3", videoUrl: "/videos/sample3.mp4" },
    { id: 3, name: "Camera 4", videoUrl: "/videos/sample4.mp4" },
  ];
  const [selectedCamera, setSelectedCamera] = useState(0);
  const [loading, setLoading] = useState(true);

  return (
    <>
      <div className="h-full w-full overflow-hidden bg-gray-100">
        {/* Grid of cameras */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 h-full overflow-y-auto hide-scrollbar p-6">
          {cameras.map((camera, index) => (
            <div
              key={camera.id}
              onClick={() => setSelectedCamera(index)}
              className={`group relative cursor-pointer rounded-lg overflow-hidden bg-gray-900 shadow-lg ${selectedCamera === index ? 'ring-2 ring-green-500' : 'hover:ring-2 hover:ring-gray-300'}`}
            >
              <div className="aspect-video relative min-h-[240px]">
                {loading ? (
                  <div className="w-full h-full flex items-center justify-center">
                    <VideoStreamPlaceholder title={camera.name} />
                  </div>
                ) : (
                  <VideoStream
                    videoUrl={camera.videoUrl}
                    title={camera.name}
                    className="w-full h-full"
                    controls={false}
                    onLoad={() => setLoading(false)}
                  />
                )}
                <div className="absolute inset-0 flex items-center justify-center bg-black/0 group-hover:bg-black/20 transition-colors">
                  <span className="text-xs font-medium text-white bg-black/50 px-2 py-1 rounded">
                    {camera.name}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>



        {/* Category-specific metrics */}
        <div className="grid grid-cols-3 gap-4 pb-4">
          <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg shadow-lg text-white">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">Animal Count</h3>
              <span className="text-xl">-</span>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg shadow-lg text-white">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">Health Status</h3>
              <span className="text-xl text-green-200">Normal</span>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg shadow-lg text-white">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">Activity</h3>
              <span className="text-xl text-blue-200">Active</span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default ViewType;
