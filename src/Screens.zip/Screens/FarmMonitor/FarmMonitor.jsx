"use client"

import { useState, useEffect } from "react"
import { useSelector } from "react-redux"
import MainLayout from "../../LayOut/MainLayout"
import VideoPlayer from "../../components/VideoPlayer/VideoPlayer"
import ViewType from "./Component/ViewType";
import ListView from "./Component/LiveView";
import ViewToggleIcons from "../../components/ViewToggleIcons";

/**
 * FarmMonitor - Page for monitoring multiple camera feeds
 * Provides grid view and detailed view options
 */
const FarmMonitor = () => {
  const [viewState, setViewState] = useState(false) // false = list view, true = category view
  const [selectedCamera, setSelectedCamera] = useState(0)
  const [availableCameras, setAvailableCameras] = useState([])
  const cameraIpAddresses = useSelector((state) => state.actions.ipAddress)

  // Set page title
  useEffect(() => {
    document.title = "Farm Monitor | DalensAI"
  }, [])

  // Initialize available cameras
  useEffect(() => {
    // Demo cameras with MP4 files
    setAvailableCameras([
      { 
        id: 0, 
        name: "Camera 1", 
        videoUrl: "/videos/camera1.mp4"
      },
      { 
        id: 1, 
        name: "Camera 2", 
        videoUrl: "/videos/camera2.mp4"
      },
      { 
        id: 2, 
        name: "Camera 3", 
        videoUrl: "/videos/camera3.mp4"
      },
      { 
        id: 3, 
        name: "Camera 4", 
        videoUrl: "/videos/camera4.mp4"
      },
    ])
  }, [])

  return (
    <MainLayout activePage="farm">
      <div className="relative h-[calc(100vh-64px)] w-full overflow-hidden">
        {/* View Toggle Icons */}
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-20">
          <ViewToggleIcons isLiveView={!viewState} onChange={setViewState} />
        </div>

        {/* Main Content */}
        {viewState ? 
          <ViewType setViewState={setViewState}/> 
          : 
          <ListView setViewState={setViewState}/>
        }
      </div>
    </MainLayout>
  )
}

export default FarmMonitor
